#include "../include/utils.h"

#include <string>
using namespace std;

Matrix multiply(Matrix mat1, Matrix mat2) {
    Matrix ans(0, 0, 0, 0); 

    int mod = 1e8;
    for(int i = 0; i < 2; i++)
        for(int j = 0; j < 2; j++)
            for(int k = 0; k < 2; k++)
                ans.sumIdx(i, j, ((mat1.getIdx(i, k)) % mod) * (mat2.getIdx(k, j) % mod) % mod);

    return ans;
}
