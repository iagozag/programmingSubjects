#include "../include/segtree.h"

#include <iostream>
using namespace std;

#define _ ios_base::sync_with_stdio(0);cin.tie(0);

int main(){ _
    int n, m; cin >> n >> m;
    Segtree segt(n);
    segt.build(1, 0, n-1);

    for(int i = 0; i < m; i++){
        char op; int idx, a, b, c, d; cin >> op;
        if(op == 'u'){
            cin >> idx >> a >> b >> c >> d;

            long long** m = new long long*[2];
            for (int i = 0; i < 2; ++i) 
                m[i] = new long long[2];
            m[0][0] = a, m[0][1] = b, m[1][0] = c, m[1][1] = d;

            segt.update(1, 0, n-1, idx, m);

            for (int i = 0; i < 2; ++i)
                delete[] m[i];
            delete[] m;
        } else{
            cin >> a >> b >> c >> d;
            long long** m = segt.query(1, 0, n-1, a, b);

            long long** aux = new long long*[2];
            for (int i = 0; i < 2; ++i) 
                aux[i] = new long long[2];
            aux[0][0] = c, aux[0][1] = 0, aux[1][0] = d, aux[1][1] = 0;

            m = multiply(m, aux);
            cout << get_less_sig(m[0][0]) << " " << get_less_sig(m[1][0]) << endl;

            for (int i = 0; i < 2; ++i) {
                delete[] m[i];
                delete[] aux[i];
            }
            delete[] m;
            delete[] aux;
        }
    }

    exit(0);
}
