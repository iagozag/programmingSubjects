#ifndef UTILS_H
#define UTILS_H

#include "../include/matrix.h"

Matrix multiply(Matrix mat1, Matrix mat2);

long long get_less_sig(long long a);

#endif
