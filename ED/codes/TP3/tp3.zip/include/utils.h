#ifndef UTILS_H
#define UTILS_H

long long** multiply(long long** mat1, long long** mat2);

long long get_less_sig(long long a);

#endif
