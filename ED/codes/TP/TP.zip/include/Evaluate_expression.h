#include <iostream>
#include <string.h>

int priority(const char& c);

std::string infix_to_postfix(const std::string& st, std::string values);

bool evaluate(const std::string& st, std::string values);
