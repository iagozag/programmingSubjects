#include <stdio.h>
#include <stdlib.h>

float max(float n1, float n2, float n3){
	if(n1 >= n2 && n1 >= n3){
		return n1;
	}
	if(n2 >= n3){
		return n2;
	}
		return n3;
	}

float min(float n1, float n2, float n3){
	float minn;
	
	if(n1 <= n2 && n1 <= n3){
		return n1;
	}
	if(n2 <= n3){
		return n2;
	}
		return n3;
	}

int main(){
	float a, b, c;
	
	scanf("%f", &a);
	scanf("%f", &b);
	scanf("%f", &c);
	
	printf("\nO maior numero eh: %.1f", max(a, b, c));
	printf("\nO menor numero eh: %.1f", min(a, b, c));
	
	
	return 0;
}
