#include <stdio.h>
#include <stdlib.h>

int bissexto(int ano){
	return ((ano % 400 == 0) || ((ano % 4 == 0) && (ano % 100 != 0)));
}

int main(){
	int ano, flag;
	scanf("%d", &ano);
	flag = bissexto(ano);
	if(flag == 1){
		printf("O ano %d eh bissexto", ano);
	} else{
		printf("O ano %d nao eh bissexto", ano);
	}
	return 0;
}
