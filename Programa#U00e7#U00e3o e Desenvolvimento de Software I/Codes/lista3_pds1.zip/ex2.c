#include <stdio.h>
#include <stdlib.h>

int par(int n){
	return ((n % 2) == 0);
	}

int dentro(int n1, int n2, int n3){
	return (n1 >= n2 && n1 <= n3);
}

int fora(int n1, int n2, int n3){
	return !dentro(n1, n2, n3);
}

int main(){
	int x, y, z;
	int flag;
	
	scanf("%d", &x);
	scanf("%d", &y);
	scanf("%d", &z);
	
	flag = par(x);
	if(flag == 1){
		printf("\nO numero %d eh par", x);
	} else{
		printf("\nO numero %d eh impar", x);
	}
	
	flag = dentro(x, y, z);
	if(flag == 1){
		printf("\n\n%d esta no intervalo [%d, %d]", x, y, z);
	} else{
		printf("\n%d nao esta no intervalo [%d, %d]", x, y, z);
	}
	
	flag = fora(x, y, z);
	if(flag == 1){
		printf("\n%d nao esta no intervalo [%d, %d]", x, y, z);
	} else{
		printf("\n%d esta no intervalo [%d, %d]", x, y, z);
	}
	
	return 0;
}
