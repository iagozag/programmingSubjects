#include <stdio.h>

int primo(int x){
    for(int i = 2; i * i <= x; i++){
        if(x % i == 0) return 0;
    }
    return 1;
}

int main(){
	int n;
	FILE* fp  = fopen("lista06.txt", "r+t");
	FILE* fp1 = fopen("lista06.2.txt", "w+t");

	if(fp == NULL || fp1 == NULL) printf("ERRO AO ABRIR ARQUIVO");
	else{
		while(fscanf(fp, "%d", &n) != EOF){
			if(primo(n) == 1) fprintf(fp1, "%d eh primo\n", n);
			else fprintf(fp1, "%d nao eh primo\n", n);
		}
	}
	fclose(fp);
	fclose(fp1);
	return 0;
}

