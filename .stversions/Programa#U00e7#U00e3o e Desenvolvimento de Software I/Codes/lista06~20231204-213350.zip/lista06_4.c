#include <stdio.h>

float funcao(float x){
	return((x*x) - (5 * x) + 1);
}

int main(){
	float n;
	FILE* fp = fopen ("reais.txt", "r+t");
	FILE* fp1 = fopen ("lista_06.4.txt", "w+t");

	if(fp == NULL || fp1 == NULL) printf("ERRO AO ABRIR ARQUIVO");
	else{
		while(fscanf(fp, "%f", &n) != EOF){
			fprintf(fp1, "f(%f) = %f\n", n, funcao(n));
		}
	}
	fclose(fp);
	fclose(fp1);
	return 0;
}
