#include <stdio.h>

int primo(int x){
    for(int i = 2; i * i <= x; i++){
        if(x % i == 0) return 0;
    }
    return 1;
}

int main(){
	int n;
	FILE* fp = fopen ("lista06.txt", "r+t");;
	FILE* fp1 = fopen ("primos.txt", "w+t");
	FILE* fp2 = fopen ("outros.txt", "w+t");

	if(fp == NULL || fp1 == NULL || fp2 == NULL) printf("ERRO AO ABRIR ARQUIVO");
	else{
		while(fscanf(fp, "%d", &n) != EOF){
			if(primo(n) == 1) fprintf(fp1, "%d ", n);
			else fprintf(fp2, "%d ", n);
		}
	}
	fclose(fp);
	fclose(fp1);
	fclose(fp2);
	return 0;
}

