#include <stdio.h>

int primo(int x){
    for(int i = 2; i * i <= x; i++){
        if(x % i == 0) return 0;
    }
    return 1;
}

int prox_primo(int x){
    while(primo(x) != 1) x++;
	return x;
}

int main(){
	int n, primos = 1;
	FILE* fp = fopen ("lista06.txt", "w+t");
	scanf("%d", &n);

    if(fp == NULL) printf("ERRO AO ABRIR ARQUIVO");
    else{
		for(int i = 0; i < n; i++){
			fprintf(fp, "%d ", primos);
			primos = prox_primo(primos + 1);
		}
	}
	fclose(fp);
	return 0;
}
