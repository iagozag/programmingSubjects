#include <stdio.h>

float funcao(float x, float a, float b, float c, float d){
	return(a * (x * x * x) + b * (x * x) + c * x + d);
}

int main(){
	float a, b, c, d, n; scanf("%f %f %f %f", &a, &b, &c, &d);
	FILE* fp = fopen ("reais.txt", "r+t");
	FILE* fp1 = fopen ("lista_06.5.txt", "w+t");

	if(fp == NULL || fp1 == NULL) printf("ERRO AO ABRIR ARQUIVO");
	else{
		while(fscanf(fp, "%f", &n) != EOF){
			fprintf(fp1, "f(%f) = %f\n", n, funcao(n, a, b, c, d));
		}
	}
	fclose(fp);
	fclose(fp1);
	return 0;
}
