#include <iostream>
#include <math.h>
using namespace std;

int main(){
	cout << "1.a) " << 3 + 4 << "\n";
	cout << "b) " << 7 / 4 << "\n";
	cout << "c) " << 3 * 3 << "\n";
	cout << "d) " << 5.3 * 2.1 << "\n";
	cout << "e) " << 2 * 5 -2 << "\n";
	cout << "f) " << 2 + 2 * 5 << "\n";
	cout << "g) " << (2 + 5) * 3 << "\n";
	cout << "h) " << sin(3.141502) << "\n";
	cout << "i) " << sqrt(5) << "\n";
	cout << "j) " << 1 + 2 + 3 << "\n";
	cout << "k) " << 1 * 2 * 3 << "\n";
	cout << "l) " << (1 + 2 + 3) / 3.0 << "\n";
	cout << "m) " << (2 + 4) * (3 - 1) << "\n";
	cout << "n) " << (9 / 3) + (3 * 2) << "\n";
	cout << "o) " << sin(4.5) + cos(3.7) << "\n";
	cout << "p) " << log(2.3) - log(3.1) << "\n";
	cout << "q) " << log(7) + (log(7) * log(7) - cos(log(7))) << "\n";
	cout << "r) " << (10.3 + 8.4) / 50.3 - (10.3 - 8.4) << "\n";
	cout << "s) " << (cos(0.8) + sin(0.8)) * (cos(0.8) - sin(0.8)) << "\n";
}
