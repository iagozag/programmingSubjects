#include <iostream>
#include <math.h>
using namespace std;

int main(){
	float a, b, c, delta, raiz1, raiz2;
	
	cout << "Digite 3 numeros(a, b, c): " << "\n";
	cin >> a >> b >> c;
	
	cout << "3.a) " << (a + b + c) / 3<< "\n";
	cout << "b) " << (a * 3  + b * 4 + b * 5) / 12 << "\n";
	cout << "c) " << 2 * M_PI * a << "\n";
	cout << "d) " << M_PI * a * a << "\n";
	cout << "e) " << (b * c) / 2 << "\n";
	cout << "f) " << sqrt((b * b) + (c * c)) << "\n";
	
	if(a != 0){
        delta = (b * b) - (4 * a * c);

        if(delta < 0){
			cout << "g) N�o tem ra�z real\n";
        }
        else if (delta == 0){
            raiz1=(-b) / (2 * a);
            
			cout << "g) Possui apenas uma raiz real: "<< raiz1 << "\n";
        }else{
            raiz1 = (-b - sqrt(delta)) / (2 * a);
            raiz2 = (-b + sqrt(delta))/(2 * a);
            
			cout << "g) ";
            cout << "1� raiz: "<< raiz1 << "\n";
            cout << "2� raiz: "<< raiz2 << "\n";
        }
    }else{
        cout << "g) Se a = 0, a equa��o n�o � do 2� grau\n";
    }
}
