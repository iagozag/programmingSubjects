#include <iostream>
#include <math.h>
using namespace std;

int main(){
	float a, b, c, d;
	cout << "Digite 4 numeros(a, b, c, d): " << "\n";
	cin >> a >> b >> c >> d;
	
	cout << "2.a) " << a + b << "\n";
	cout << "b) " << a / c << "\n";
	cout << "c) " << a * a << "\n";
	cout << "d) " << b * c << "\n";
	cout << "e) " << a * b - c << "\n";
	cout << "f) " << a + b * c << "\n";
	cout << "g) " << (a + b) * c << "\n";
	cout << "h) " << sin(a) << "\n";
	cout << "i) " << sqrt(b) << "\n";
	cout << "j) " << a + b + c << "\n";
	cout << "k) " << a * b * c << "\n";
	cout << "l) " << (a + b + c) / d << "\n";
	cout << "m) " << (a + b) * (a - d) << "\n";
	cout << "n) " << (b / c) + (a * d) << "\n";
	cout << "o) " << sin(b) + cos(c) << "\n";
	cout << "p) " << log(a) - log(c) << "\n";
	cout << "q) " << log(a) + (log(b) * log(d) - cos(log(c))) << "\n";
	cout << "r) " << (b + a) / c - (d + a) << "\n";
	cout << "s) " << (cos(d) + sin(c)) * (cos(b) - sin(a)) << "\n";
}
