#ifndef MACROS_H
#define MACROS_H

#include <bits/stdc++.h>
#include <gmpxx.h>
#include <assert.h>

using namespace std;

#define sz(a) (int)(a.size())
#define endl '\n'
#define eb push_back

typedef mpz_class mc;
typedef long long ll;
typedef vector<mc> vm;
typedef vector<vm> Matrix;

#endif // MACROS_H
